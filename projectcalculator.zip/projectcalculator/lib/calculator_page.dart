import 'package:flutter/material.dart';
import 'main.dart';

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  String input = '';
  String result = '';

  void _append(String value) {
    setState(() => input += value);
  }

  void _clear() {
    setState(() {
      input = '';
      result = '';
    });
  }

  void _calculate() {
    try {
      result = _evaluateExpression(input);
      MyApp.history.add('$input = $result');
      setState(() {});
    } catch (e) {
      result = 'Error';
      setState(() {});
    }
  }

  String _evaluateExpression(String expression) {
    expression = expression.replaceAll('×', '*').replaceAll('÷', '/');
    final parsed = RegExp(r'[\d.]+|[-+*/()]')
        .allMatches(expression)
        .map((e) => e.group(0)!)
        .toList();

    List<String> postfix = [];
    List<String> stack = [];

    Map<String, int> prec = {
      '+': 1, '-': 1,
      '*': 2, '/': 2,
    };

    for (var token in parsed) {
      if (RegExp(r'^\d+\.?\d*$').hasMatch(token)) {
        postfix.add(token);
      } else if ('+-*/'.contains(token)) {
        while (stack.isNotEmpty && prec[stack.last] != null && prec[stack.last]! >= prec[token]!) {
          postfix.add(stack.removeLast());
        }
        stack.add(token);
      }
    }
    while (stack.isNotEmpty) {
      postfix.add(stack.removeLast());
    }

    List<double> calcStack = [];
    for (var token in postfix) {
      if (RegExp(r'^\d+\.?\d*$').hasMatch(token)) {
        calcStack.add(double.parse(token));
      } else {
        var b = calcStack.removeLast();
        var a = calcStack.removeLast();
        switch (token) {
          case '+': calcStack.add(a + b); break;
          case '-': calcStack.add(a - b); break;
          case '*': calcStack.add(a * b); break;
          case '/': calcStack.add(a / b); break;
        }
      }
    }

    return calcStack.single.toString();
  }

  Widget _buildButton(String label) {
    return Container(
      margin: const EdgeInsets.all(4),
      constraints: const BoxConstraints(minHeight: 50, minWidth: 50, maxHeight: 80, maxWidth: 80),
      child: ElevatedButton(
        onPressed: () {
          if (label == 'C') return _clear();
          if (label == '=') return _calculate();
          _append(label);
        },
        child: Text(label, style: const TextStyle(fontSize: 22)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const buttons = [
      ['7', '8', '9', '/'],
      ['4', '5', '6', '*'],
      ['1', '2', '3', '-'],
      ['0', '.', 'C', '+'],
      ['='],
    ];

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(input, style: const TextStyle(fontSize: 24)),
          const SizedBox(height: 10),
          Text(result, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          ...buttons.map((row) => Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: row.map(_buildButton).toList(),
          )),
        ],
      ),
    );
  }
}
