import 'package:flutter/material.dart';
import 'main.dart';

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    final history = MyApp.history.reversed.toList();

    return Center(
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: history.length,
        itemBuilder: (context, index) {
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(history[index], style: const TextStyle(fontSize: 18)),
            ),
          );
        },
      ),
    );
  }
}
